# OpenBCI_Wifi_Master_Library
The Arduino library for to controlling Wifi Shield on Cyton/Ganglion (really any Arduino device).

The purpose is to create a single code base for the Cyton and Ganglion to use, that way when we patch a bug or make and improvement it transfers to both boards. 
