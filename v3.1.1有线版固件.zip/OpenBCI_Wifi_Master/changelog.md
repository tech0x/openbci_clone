# v1.0.0

### Breaking Changes

* String messages are now sent with `\0` which really really helped the conversion to clean strings on the wifi shield!

## Release Candidate 2

### New Functions

* Add `sendStringMulti(char)`

## Release Candidate 1

First releases

# v0.0.3

### Bug Fixes

* Added sentGains = false to reset function

# v0.0.2

### New Features

* Added public boolean variable `sentGains` to trigger an initial send of gains from Cyton or Ganglion.

# v0.0.1

Initial Release
